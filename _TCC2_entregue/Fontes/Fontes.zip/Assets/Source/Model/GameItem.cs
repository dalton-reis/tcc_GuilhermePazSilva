﻿namespace Assets.Source.Model
{
    public class GameItem
    {

    }
}