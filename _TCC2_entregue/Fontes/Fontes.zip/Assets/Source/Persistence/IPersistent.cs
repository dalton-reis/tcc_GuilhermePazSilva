﻿public interface IPersistent
{
    PersistenceData GetData();
    void SetData(PersistenceData data);
}