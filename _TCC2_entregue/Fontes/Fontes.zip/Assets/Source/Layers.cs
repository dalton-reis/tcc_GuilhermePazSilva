﻿namespace Assets.Source
{
    public enum Layers
    {
        Terrain,
        Construction,
        Above,
        Entities
    }
}