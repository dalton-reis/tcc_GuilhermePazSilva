﻿using UnityEngine;

public class EditorTile : MonoBehaviour
{
    public int x;
    public int y;
    public int tid;
}
