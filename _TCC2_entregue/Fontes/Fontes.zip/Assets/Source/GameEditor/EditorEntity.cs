﻿using Assets.Source.Model;
using UnityEngine;

public class EditorEntity : MonoBehaviour
{
    public GameEntity gameEntity;
}
