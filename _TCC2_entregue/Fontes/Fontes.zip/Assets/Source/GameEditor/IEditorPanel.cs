﻿namespace Assets
{
    public interface IEditorPanel
    {
        void DialogOpened();
    }
}